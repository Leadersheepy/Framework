import 'package:flutter/material.dart';

Color fondCardColor = Color(0xFFFAEAED);
Color textEntreprise = Color(0xFF323C5E);
Color textPetit = Color(0xFF878EBF);