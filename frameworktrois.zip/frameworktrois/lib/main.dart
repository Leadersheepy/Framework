

// -----------------EXERCICE MODEL HIVE-----------------------------
import 'package:flutter/material.dart';
import 'package:frameworktrois/color.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:hive_flutter/adapters.dart';
import 'color.dart';


// Vu que l'on utilise Hive pour se projet, il faut avant tout ajouter dans pubspec.yaml
// la version de hive qu'on utilise (pour ensuite l'importer sur notre fichier)

//-----------------MIS EN PLACE------------------------------------
void main() async {
  //Mis en marche de Hive et ouverture de la "box" (zone qui va garder les informations
  //qu'on aura envoyer lors de nos créations de jobs -> un peu comme une base SQL
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await Hive.openBox('job_box');
  runApp(const MyApp());
}
//-----------------------------------------------------

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Frameworktrois',
      theme: ThemeData(
        primarySwatch: Colors.pink,
      ),
      home: const mainPage(),
    );
  }
}

class mainPage extends StatefulWidget {
  const mainPage({Key? key}) : super(key: key);

  @override
  _mainPageState createState() => _mainPageState();
}

class _mainPageState extends State<mainPage> {
  //préparation de l'élèment liste
  List<Map<String, dynamic>> _jobs = [];
  //création de la box pour les jobs
  final _jobBox = Hive.box('job_box');

  @override
  void initState() {
    super.initState();
    _actualiser();
    // Permet de récupérer les donées que l'on a déjà mit lors de nos
    // autres session
  }

  //-------------------RECUPERATION----------------------------------
  // Cette partie permet de récupérer tout les élèments de notre base de donnée !
  // grâce à keys et value
  void _actualiser() {
    final data = _jobBox.keys.map((key) {
      final value = _jobBox.get(key);
      return {"key": key,
        "entreprise": value["entreprise"],
        "salaireBrutAnnuel": value["salaireBrutAnnuel"],
        "choixStatut": value["choixStatut"],
        "salaireNetMensuel": value["salaireNetMensuel"],
        "monSentiment": value["monSentiment"],};
    }).toList();

    setState(() {
      _jobs = data.toList();
    });
  }
//-----------------------------------------------------

  //------------------------- AJOUT ----------------------------
  // Le .add permet d'ajouter un élèment à la liste et donc de le sauvegarder
  // dans notre base de donnée ! De plus ça rajoutera sans autre manoeuvre
  // supplémentaire ! (ça rajoutera un peu comme dans une base de donnée
  // un id qui commencera à 0 pour le premier job)

  Future<void> _createItem(Map<String, dynamic> newItem) async {
    await _jobBox.add(newItem);
    _actualiser();
  }
  //-----------------------------------------------------


  //-------------------------MODIFIER----------------------------

  Future<void> _updateItem(int itemKey, Map<String, dynamic> item) async {
    // Ici on va mettre à jour nos donner grâce à .put et à partir de l'icone
    //modifier, ce qui mettra à jour la liste dans notre base de donnée
    // et donc notre liste
    await _jobBox.put(itemKey, item);
    _actualiser();
  }
  //-----------------------------------------------------

  //-------------------SUPPRIMER----------------------------------
  Future<void> _deleteItem(int itemKey) async {
    //Le .delete nous permet de supprimer l'élèment en question de la base de donnée
    // et donc le supprimer de notre liste
    await _jobBox.delete(itemKey);
    _actualiser();
  }
  //-----------------------------------------------------

  bool isExpense = true;

  // Ajout des variables que l'on a besoin
  final TextEditingController _entrepriseController = TextEditingController();
  final TextEditingController _salaireBrutAnnuelController = TextEditingController();
  final TextEditingController _choixStatutController = TextEditingController();
  final TextEditingController _salaireNetMensuelController = TextEditingController();
  final TextEditingController _monSentimentController = TextEditingController();


  //-----------------------CREATION DU JOBS + BOUTON ------------------------------

  // Ici on s'attaque à la partie création, _creationJob va permettre donc de
  //créer notre partie où l'on va rentrer les données que l'on veut
  //pour chaque fiche de métier

  void _creationJob(BuildContext ctx, int? itemKey) async {

    // la particularité de cette partie est que l'on va aussi l'utiliser
    // pour  éditer nos jobs, pour ce faire on va utiliser un if :
    // si TOUT les élèments du jobs existent déjà, alors on va modifier les valeurs
    // sinon, on en crée un nouveau


    if (itemKey != null) {

      final existingItem =
      _jobs.firstWhere((element) => element['key'] == itemKey);

      _entrepriseController.text = existingItem['entreprise'];
      _salaireBrutAnnuelController.text = existingItem['salaireBrutAnnuel'];
      _choixStatutController.text = existingItem['choixStatut'];
      _salaireNetMensuelController.text = existingItem['salaireNetMensuel'];
      _monSentimentController.text = existingItem['monSentiment'];

    }


    showModalBottomSheet (
      //Le showModalbottom sheet permet de faire afficher un élèment sans que l'utilisateur
      //puisse toucher à la "page d'avant/en dessous"
        context: ctx,
        elevation: 5,
        isScrollControlled: true,

        builder: (_) => Container(
          //le padding permet de mettre un écart pour chaque côté
          padding: EdgeInsets.only(
              bottom: 20,
              top: 15,
              left: 55,
              right: 55),

          child: Container(
          //taille de la box
            height: 400,
            width: 700,

            child: Column(
              children: [
                Text('Un nouveau job apparait !! :^O ',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 32,
                    color: Colors.pinkAccent,
                  ),
                ),

                //---------------------EXEMPLE d'ENTREE DE DONNEE------------------------------------
                TextField(
                  //ici on va donc créer un élèment grâce à controller qu'on importera dans d'autre fonction
                  controller: _entrepriseController,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Entreprise'),
                ),
                const SizedBox(
                  height: 10,
                ),
                //-----------------------------------------------------------------------------------

                TextField(
                  controller: _salaireBrutAnnuelController,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Salaire brut annuel'),
                ),
                const SizedBox(
                  height: 10,
                ),

                //RadioListTile<bool>(
                //  title: Text('Expense'),
                //  value: true,
               //   groupValue: isExpense,
               //   onChanged: (value) => setState(() => isExpense = value!),
              //  ),

              //  RadioListTile<bool>(
              //    title: Text('Income'),
              //    value: false,
              //    groupValue: isExpense,
              //    onChanged: (value) => setState(() => isExpense = value!),
              //  ),

            TextField(
                  controller: _choixStatutController,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Choix statut proposé'),
                ),
                const SizedBox(
                  height: 10,
                ),

                TextField(
                  controller: _salaireNetMensuelController,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Salaire net mensuel'),
                ),
                const SizedBox(
                  height: 10,
                ),

                TextField(
                  //celui est différent des autres textflied car je
                  //ne lui ai pas mit de border
                  controller: _monSentimentController,
                  decoration: InputDecoration(
                      hintText: 'Mon sentiment'),
                ),
                const SizedBox(
                  height: 20,
                ),

//---------------------------------------

                ElevatedButton(
                  //le bouton va envoyer les donner ou les modifiers si
                  // TOUTES les données existait déjà sur une même fiche de job
                  onPressed: () async {

                    if (itemKey == null) {
                      _createItem({
                        "entreprise": _entrepriseController.text,
                        "salaireBrutAnnuel": _salaireBrutAnnuelController.text,
                        "choixStatut": _choixStatutController.text,
                        "salaireNetMensuel": _salaireNetMensuelController.text,
                        "monSentiment": _monSentimentController.text,

                      });
                    }

                    if (itemKey != null) {
                      _updateItem(itemKey, {
                        "entreprise": _entrepriseController.text.trim(),
                        "salaireBrutAnnuel": _salaireBrutAnnuelController.text.trim(),
                        "choixStatut": _choixStatutController.text.trim(),
                        "salaireNetMensuel": _salaireNetMensuelController.text.trim(),
                        "monSentiment": _monSentimentController.text.trim(),
                      });
                    }

                    // Permet de retirer ce que l'on avait écrit
                    _entrepriseController.text = '';
                    _salaireBrutAnnuelController.text = '';
                    _choixStatutController.text = '';
                    _salaireNetMensuelController.text = '';
                    _monSentimentController.text = '';

                    Navigator.of(context).pop(); // ferme la page
                  },
                  child: Text(itemKey == null ? 'Et hop un nouveau job ! :-)' : 'Tout beau tout propre'),
                ),

                const SizedBox(
                  height: 15,
                ),

              ],
            ),
          )
        )
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mon suivi de jobs :^D'),
      ),

      body:

      ListView.builder(
        //la liste des jobs que l'on a crée
          itemCount: _jobs.length,
          itemBuilder: (_, index) {
            final currentItem = _jobs[index];
            return Card(
              color: fondCardColor,
              margin: const EdgeInsets.all(4),
              elevation: 3,
              child: ListTile(
                //ici on créait notre liste qui s'affichera dans la première pas
                // On a 3 parties possible dans une listTile Title, Subtitle et Trailing
                  title: Text( "Entreprise : " + currentItem['entreprise'] ),
                  subtitle: Text(
                      "\n Salaire brut annuel : " + currentItem['salaireBrutAnnuel'].toString() +"€"
                      + "\n Choix statute proposé : " + currentItem['choixStatut'].toString() +"€"
                          + "\n Salaire net mensuel : " + currentItem['salaireNetMensuel'].toString() +"€"
                          + "\n Mon sentiment : "  + currentItem['monSentiment'].toString()),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [

                      IconButton(
                          icon: const Icon(Icons.edit),
                          onPressed: () =>
                              _creationJob(context, currentItem['key'])),

                      IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () => _deleteItem(currentItem['key']),
                      ),
                    ],
                  )),
            );
          }),

      // Add new item button
      floatingActionButton:SizedBox.fromSize(

        size: Size(100, 60),
        child: ClipOval(

          child: Material(
            color: Colors.pinkAccent,
            // ton color
            child: InkWell(
              splashColor: Colors.pink,
              onTap: () => _creationJob(context, null),

              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,

                children: <Widget>[
                  Icon(Icons.add), // icon
                  Text("Ajout",
                    style: TextStyle(
                      color: Colors.white,),),
                ],

              ),
            ),
          ),
        ),
      ),
    );
  }
}