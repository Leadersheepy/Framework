package com.example.frameworktrois

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
