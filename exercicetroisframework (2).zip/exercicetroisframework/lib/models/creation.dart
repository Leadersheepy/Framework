import 'package:flutter/material.dart';

//Ajout des élèments de la liste

class Jobs{
  final String entreprise;
  final String salaireBrutAnnuel;
  final String choixStatutPropose;
  final String salaireNetMensuel;
  final String monSentiment;

  Jobs(this.entreprise, this.salaireBrutAnnuel, this.choixStatutPropose, this.salaireNetMensuel, this.monSentiment); //constructor

}