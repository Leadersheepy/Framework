import 'package:flutter/material.dart';

//Dans cette partie on va créer nos élèments qu'on utilisera pour notre fiche jobs

class Jobs{
  final String entreprise;
  final String salaireBrutAnnuel;
  final String choixStatutPropose;
  final String salaireNetMensuel;
  final String monSentiment;

  Jobs(this.entreprise, this.salaireBrutAnnuel, this.choixStatutPropose, this.salaireNetMensuel, this.monSentiment); //constructor

}