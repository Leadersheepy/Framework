import 'package:exercicetroisframework/models/creation.dart';
import 'package:exercicetroisframework/creationfiche.dart';
import 'package:flutter/material.dart';

import 'color.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MaList(),
      title : 'Exercice 3',
      theme: ThemeData(
        primarySwatch: Colors.pink,
      ),
    );
  }
}

class MaList extends StatefulWidget {
  const MaList({Key? key}) : super(key: key);

  @override
  _MaListState createState() => _MaListState();
}


class _MaListState extends State<MaList> {

  List<Jobs> jobList = [];

  @override
  Widget build(BuildContext context) {

    //On ajoute la liste avec .add
    void ajoutJobData(Jobs jobs){
      setState(() {
        jobList.add(jobs);
      });
    }

    void affichageJob(){
      showDialog(context: context, builder: (_){
        return AlertDialog(
          content: ajoutJobPage(ajoutJobData),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        );
        },);
    }

    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: affichageJob,
        child: Icon(Icons.add),
      ),

      appBar: AppBar(
        title: Text('Mon suivi de jobs :^D'),
      ),

      body: Container(
        child: ListView.builder(itemBuilder: (context,index){
          // Card va permettre d'afficher notre liste avec un certain design (plus librement)
          return Card(
            child: ListTile(
              title: Text("Mon entreprise : " + jobList[index].entreprise,
                style: TextStyle(
                  fontSize: 22,
                  color: textEntreprise,
                  fontWeight: FontWeight.w400,
                ),
              ),
// Ajout de nos données sur la liste
              subtitle:  Text(
                "Salaire brut annuel : "
                    + jobList[index].salaireBrutAnnuel
                    + "\nChoix statut proposé : "
                    + jobList[index].choixStatutPropose
                    + "\nSalaire net mensuel : "
                    + jobList[index].salaireNetMensuel
                    + "\nMon sentiment : "
                    + jobList[index].monSentiment,

                style: TextStyle(
                  color: textPetit,
                ),),

                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Edit button
                    IconButton(
                        icon: const Icon(Icons.edit),
                        onPressed: () => {}
                    ),
                    // Delete button
                    IconButton(
                      icon: const Icon(Icons.delete),
                      onPressed: () => {},
                    ),
                  ],
                )
            ),
            color:fondCardColor,
          );
          },
          itemCount: jobList.length,),
      ),

    );
  }
}
