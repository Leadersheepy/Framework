import 'package:exercicetroisframework/models/creation.dart';
import 'package:flutter/material.dart';

class ajoutJobPage extends StatefulWidget {

  final Function(Jobs) ajoutJob;

  ajoutJobPage(this.ajoutJob);

  @override
  _ajoutJobState createState() => _ajoutJobState();
}

class _ajoutJobState extends State<ajoutJobPage> {

 // var calcul;
//Tentative de calcul
 // calculInteret(salaireBrut, detailCadre){
 //   calcul= (salaireBrut * detailCadre);
 // }


  @override
  Widget build(BuildContext context) {
    Widget buildTextfield(String hint, TextEditingController controller){

      return Container(
        margin: EdgeInsets.all(4),
        child: TextField(
          decoration: InputDecoration(
            labelText: hint,
            border: OutlineInputBorder(
              borderSide: BorderSide(
                color: Colors.black38,
              ),
            ),
          ),
          controller: controller,
        ),
      );

    }

    //création des variables controller
    var entreprise = TextEditingController();
    var salaireBrutAnnuel = TextEditingController();
    var choixStatutPropose = TextEditingController();
    var salaireNetMensuel = TextEditingController();
    var monSentiment = TextEditingController();


    // TENTATIVE DE CALCUL
    int _value = 0;

    void _cadre(){
      setState(() {
        if (_value == 1) {
          _value = 25;
        } else {
          _value = 22;

        }
      });
    }

    return Container(
      height: 500,
      width: 800,

      child: Column(
        children: [
          Text('Un nouveau job apparait !! :^O ',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 32,
              color: Colors.pinkAccent,
            ),
          ),


          //------------------création des zones de textes----------------


          buildTextfield('Entreprise', entreprise),
          buildTextfield('Salaire Brut Annuel', salaireBrutAnnuel),

          Spacer(),

          Row(
            children: [
              const Text('Choix statut proposé : '),
              Radio(
                  value: 1,
                  groupValue: _value,
                  onChanged: (value) {}
              ),
              const Text('Cadre (25%)'),
              Radio(
                value: 2,
                groupValue: _value,
                onChanged: (value){},
              ),
              const Text('Non Cadre (22%) '),
            ],
          ),

          RichText(
            text: TextSpan(
              text: 'Tu es un.e adulte maintenant ! Donc pour calculer tu prends ton % que tu as cochés et tu fais : ',
              style: DefaultTextStyle.of(context).style,
              children: const <TextSpan>[
                TextSpan(text: '\n Salaire brut Annuel x ((100 - le pourcentage)/100)', style: TextStyle(fontWeight: FontWeight.bold)),
                TextSpan(text: ' \n Tu me remercieras plus tard ! :-p '),
              ],
            ),
          ),

          Spacer(),

          buildTextfield('Choix Statut Proposé', choixStatutPropose),
          buildTextfield('Salaire Net Mensuel', salaireNetMensuel),
          buildTextfield('Mon sentiment', monSentiment),

          Spacer(),

          ElevatedButton(
            onPressed: () {
              //TENTATIVE DE CALCULE
             // calculInteret(
             //     int.parse(salaireBrutAnnuel),
             //     int.parse(choixStatutPropose)
              //);
              //envois des données crées
              final jobs = Jobs(entreprise.text, salaireBrutAnnuel.text, salaireNetMensuel.text, choixStatutPropose.text, monSentiment.text);
              widget.ajoutJob(jobs);
              //fin de la création
              Navigator.of(context).pop();
            },
            child:
            Text('Et hop un nouveau job :^) ! '),
          )

        ],
      ),
    );
  }
}