import 'package:flutter/material.dart';

class User{
  final String entreprise;
  final String salaireBrutAnnuel;
  final String choixStatutPropose;
  final String salaireNetMensuel;
  final String monSentiment;

  User(this.entreprise, this.salaireBrutAnnuel, this.choixStatutPropose, this.salaireNetMensuel, this.monSentiment); //constructor

}