import 'package:exercicetroisframework/models/creation.dart';
import 'package:exercicetroisframework/creationfiche.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyFlutterList(),
      title : 'Exercice 3',
      theme: ThemeData(
        primarySwatch: Colors.pink,
      ),
    );
  }
}

class MyFlutterList extends StatefulWidget {
  const MyFlutterList({Key? key}) : super(key: key);

  @override
  _MyFlutterListState createState() => _MyFlutterListState();
}


class _MyFlutterListState extends State<MyFlutterList> {

  List<User> userList = [];

  @override
  Widget build(BuildContext context) {

    void addUserData(User user){
      setState(() {
        userList.add(user);
      });
    }

    void showUserDialog(){
      showDialog(context: context, builder: (_){
        return AlertDialog(
          content: AddUserDialog(addUserData),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        );
        },);
    }

    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: showUserDialog,
        child: Icon(Icons.add),
      ),

      appBar: AppBar(
        title: Text('Mon suivi de jobs :^D'),
      ),

      body: Container(
        child: ListView.builder(itemBuilder: (context,index){
          return Card(
            child: ListTile(
              title: Text("Mon entreprise : " + userList[index].entreprise,
                style: TextStyle(
                  fontSize: 22,
                  color: Colors.purple,
                  fontWeight: FontWeight.w400,
                ),
              ),

              subtitle:  Text(
                "Salaire brut annuel : "
                    + userList[index].salaireBrutAnnuel
                    + "\nChoix statut proposé : "
                    + userList[index].choixStatutPropose
                    + "\nSalaire net mensuel : "
                    + userList[index].salaireNetMensuel
                    + "\nMon sentiment : "
                    + userList[index].monSentiment,

                style: TextStyle(
                  color: Colors.pinkAccent,
                ),),

            ),
          );
          },
          itemCount: userList.length,),
      ),
    );
  }
}
