import 'package:exercicetroisframework/models/creation.dart';
import 'package:flutter/material.dart';

class AddUserDialog extends StatefulWidget {

  final Function(User) addUser;

  AddUserDialog(this.addUser);

  @override
  _AddUserDialogState createState() => _AddUserDialogState();
}

class _AddUserDialogState extends State<AddUserDialog> {

  @override
  Widget build(BuildContext context) {

    Widget buildTextfield(String hint, TextEditingController controller){

      return Container(
        margin: EdgeInsets.all(4),
        child: TextField(
          decoration: InputDecoration(
            labelText: hint,
            border: OutlineInputBorder(
              borderSide: BorderSide(
                color: Colors.black38,
              ),
            ),
          ),
          controller: controller,
        ),
      );

    }

    var entreprise = TextEditingController();
    var salaireBrutAnnuel = TextEditingController();
    var choixStatutPropose = TextEditingController();
    var salaireNetMensuel = TextEditingController();
    var monSentiment = TextEditingController();


    return Container(
      height: 800,
      width: 800,
      child: Column(
        children: [
          Text(
            'Add User',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 32,
              color: Colors.pinkAccent,
            ),
          ),

          buildTextfield('Entreprise', entreprise),
          buildTextfield('Salaire Brut Annuel', salaireBrutAnnuel),
          buildTextfield('Choix Statut Proposé', choixStatutPropose),
          buildTextfield('Salaire Net Mensuel', salaireNetMensuel),
          buildTextfield('Mon sentiment', monSentiment),

          ElevatedButton(
            onPressed: () {

              final user = User(entreprise.text, salaireBrutAnnuel.text, choixStatutPropose.text, salaireNetMensuel.text, monSentiment.text);
              widget.addUser(user);
              Navigator.of(context).pop();
            },
            child:
            Text('Add User'),
          )

        ],
      ),
    );
  }
}