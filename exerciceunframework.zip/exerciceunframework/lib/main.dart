import 'package:flutter/material.dart';
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Exercice 1',
      theme: ThemeData(

        primarySwatch: Colors.lightGreen,
      ),
      home: const MyHomePage(title: 'Flutter Exercice 1'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _count = 0;

  //Ici c'est la partie où l'on va mettre les fonctions qu'on utilisera plus tard dans notre code !
  //On a donc le decompte et ajouter

  void _decompte(){
    setState(() {
      _count--;
      //le _count--; retirera 1
    });
  }
  void _ajouter() {
    setState(() {
      if (_count == 10) {
        //si _count est égal à 10 équivaut à si lorsqu'on appuit sur le + le compteur est déjà à 10 alors ...
        _count = 0;
        //déjà nous remettons le compteur à 0 pour lorsque l'on reviendra à la page
        Navigator.of(context).push(_createRoute());
        //Mais surtout nous lui demandons de naviguer sur une autre page
      } else {
        //Et si nous ne sommes toujours pas à 10 avec on rajoute +1
        _count++;
      }
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(


        title: Text(widget.title),
      ),
      body: Center(

        child: Column(
          //Permet d'aligner tout au centre
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text(
              'Trouver le nombre magique pour le faire danser ! ',
            ),
            Text('$_count', style: Theme.of(context).textTheme.headline4,),
            Image.asset("images/dance1.gif",
              height: 125.0,
              width: 125.0,),

          //Image asset permet de mettre une image (ou un gif ici) dans notre application, ATTENTION cependant pour que cela fonctionne
          // Il faut modifier le pubspec.yaml pour retirer en commentaire assets et mettre le chemin d'accès des images
            // Ici par exemple c'est -images/
          ],

        ),

      ),

      //Ajout des deux boutons !
      //Nos boutons ici sont sous format icon, ce qui veut dire qu'ils seront de base
      //Rond et auront la possibilité d'avoir une icon (ici remove et add)

      floatingActionButton: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
              FloatingActionButton(
                  child: Icon(Icons.remove),
                  onPressed:_decompte,
                ),
//taille des boutons
                SizedBox(
                  width: 20.0,
                ),

                FloatingActionButton(
                  child: Icon(Icons.add),
                  onPressed: _ajouter,
                  //Onpressed permet de lier un bouton à une fonction
                ),
        ],
      ),

    );
  }
}


// Ici c'est la partie changement de page, elle nous permet donc de passer d'une page à une autre grâce au bouton
//Mentionnés
Route _createRoute() {
  return PageRouteBuilder(
    //Cette partie là c'est pour l'animation et le changement de page !
    //Begin, end et curve permette de dire comment l'animation va se dérouler
    pageBuilder: (context, animation, secondaryAnimation) => const Page2(),
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      const begin = Offset(0.0, 1.0);
      const end = Offset.zero;
      const curve = Curves.ease;
      var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

      return SlideTransition(
        position: animation.drive(tween),
        child: child,
      );
    },
  );
}


//Ici est le début de la seconde page

class Page2 extends StatelessWidget {
  const Page2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
      ),
      body: Center(
        child: Column(
          //Le Mains axis alignement est différent de celui qu'on utilise plus haut
          // Car spaceAround nous permet de mettre un espace entre chaque container

            mainAxisAlignment: MainAxisAlignment.spaceAround,
            //Les container sont utilisés ici car nous voulons afficher du text ET un bouton
            // Toutefois étant les deux des child, il est impossible de les mettres sans rajouter un layout
            // correspondant à ce que l'on veut, on partira donc ici sur des container
          //
            children: <Widget>[
              Container(
                child: Text('Bravo :D'),

              ),
              Image.asset("images/dance2.gif",
                ),

              Container(
                width: 100,
                height: 50,

                child: ElevatedButton(
                  onPressed: () {
                  Navigator.pop(context);
                  },
                  child: const Text('Retour'),

                ),
              ),
    ]
    ),
    ),
    );
  }
}