import 'package:flutter/material.dart';
import 'package:exercicedeuxframework/pages/MyHomePage.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  //Avant toute chose, il faut savoir que contrairement à l'exercice 1, ici
  //Notre code est divisé en plusieurs parties, dans plusieurs fichier séparés dans plusieurs document

  //Il ne faut donc pas oublier de les importer !

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Counter',
      theme: ThemeData(
        primarySwatch: Colors.purple,
        //Permet de changer la couleur de la navigation
        //Toute fois le bouton dans la page prendra aussi la même couleur !
      ),
      home: const MyHomePage(title: 'Flutter Calculation App'),
    );
  }
}