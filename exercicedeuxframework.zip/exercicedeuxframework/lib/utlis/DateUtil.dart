import 'package:flutter/material.dart';

import '../models/DateDuration.dart';

//C'est dans cette page que tout les calculs vont être fait
// Chaque partie est séparée correctement pour qu'à la fin on puiss récupérer facilement les données que l'on veut

class DateUtil {

  //Initialisation
  DateDuration _dateDuration = DateDuration(0, 0, 0, 0, 0, 0);

  DateTime dateTime1;

  DateUtil(this.dateTime1);
//calcul de l'année
  //On soustrait les deux années en empéchant les années négative en mettant à 0
  //Si c'est le cas
  DateDuration calculateYears(DateTime dateTime2){
    _dateDuration.years += dateTime1.year - dateTime2.year;
    if ( _dateDuration.years < 0 ){
      _dateDuration.years = 0;
    }
    return _dateDuration;
  }

  //On calcule le mois de la même manière, mais en prenant en compte
  //Que dans 1 an il y a 12 mois DONC si on dépasse les 12 mois, on retire un an
  //Dans le calcule des années
  DateDuration calculateMonth(DateTime dateTime2){
    _dateDuration.month += dateTime1.month - dateTime2.month;
    if( _dateDuration.month < 0 ){
      _dateDuration.years --;
      _dateDuration.month += 12;
    }
    calculateYears(dateTime2);
    return _dateDuration;
  }

  DateDuration calculateDays(DateTime dateTime2){
    _dateDuration.days += dateTime1.day - dateTime2.day;
    if( _dateDuration.days < 0 ){
      _dateDuration.month --;
      DateTime birthDayMonth = DateTime(dateTime2.year,dateTime2.month,0).toUtc();
      int numbDay = DateTime(dateTime2.year,dateTime2.month + 1,0).toUtc().difference(birthDayMonth).inDays;
      _dateDuration.days += numbDay;
    }
    calculateMonth(dateTime2);
    return _dateDuration;
  }

  //Pour le calcul des heures il faudra prendre en compte les jours
  //S'ils dépassent les 24, alors on retirera 1 jour dans le calculs des jours

  DateDuration calculateHours(DateTime dateTime2){
    _dateDuration.hours += dateTime1.hour - dateTime2.hour;
    if( _dateDuration.hours < 0 ){
      _dateDuration.days --;
      _dateDuration.hours += 24;
    }
    calculateDays(dateTime2);
    return _dateDuration;
  }

  //Pour le calcul des minutes il faudra prendre en compte les heures
  //S'ils dépassent les 60, alors on retirera 1 heure dans le calculs des heures
  DateDuration calculateMinutes(DateTime dateTime2){
    _dateDuration.minutes += dateTime1.minute - dateTime2.minute;
    if( _dateDuration.minutes < 0 ){
      _dateDuration.hours --;
      _dateDuration.minutes += 60;
    }
    calculateHours(dateTime2);
    return _dateDuration;
  }

  //Pour le calcul des secondes il faudra prendre en compte les minutes
  //S'ils dépassent les 60, alors on retirera 1 minutes dans le calculs des minutes
  DateDuration calculateSeconds(DateTime dateTime2){
    _dateDuration.seconds += dateTime1.second - dateTime2.second;
    if( _dateDuration.seconds < 0 ) {
      _dateDuration.minutes --;
      _dateDuration.seconds += 60;
    }
    calculateMinutes(dateTime2);
    return _dateDuration;
  }


}