import 'package:flutter/material.dart';

Color gradientStartColor = Color(0xFF9354B9);
Color gradientEndColor = Color(0xFF6751B5);

//Color.dart est une sorte de base de donnée des couleurs
//En effet on va mettre toute les couleurs que l'on veut utiliser dans notre page
// Ici juste deux
// Et on pourra les appeler lorsque l'on en aura besoin (un peu comme Date Duration .dart