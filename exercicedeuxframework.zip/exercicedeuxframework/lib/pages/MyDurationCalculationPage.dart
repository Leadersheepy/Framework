import 'package:flutter/material.dart';

import '../models/DateDuration.dart';
import '../utlis/DateUtil.dart';
import 'color.dart';

class MyDurationCalculationPage extends StatefulWidget {
  const MyDurationCalculationPage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyDurationCalculationPage> createState() => _MyDurationCalculationPageState();
}

// Cette page concerne la deuxième partie de l'exercice
//Avant nous devions calculer la date de naissance en détail mais ici on fera la différence entre deux dates !

class _MyDurationCalculationPageState extends State<MyDurationCalculationPage> {
//Le compteur sera de base à zero
  int _durationYears = 0, _durationMonth = 0, _durationDays = 0;

  DateTime _dateTime1 = DateTime.now().add(const Duration(days: -1));
  DateTime _dateTime2 = DateTime.now();

// On prépare les deux élèments/fonctions qu'on aura besoin pour notre code
  //Toute fois ici, il faut prendre en compte que la première date ne doit pas être pareil que la seconde !
  //On aura donc un écart de 1 JOUR

  void _showDatePicker1() async {
    DateTime? _newDate = await showDatePicker(
      context: context,
      initialDate: _dateTime1,
      firstDate: DateTime(0000),
      lastDate: _dateTime2.add(const Duration(days: -1)),
    );
    if(_newDate != null){
      setState(() {
        _dateTime1 = _newDate;
      });
    }
  }

  void _showDatePicker2() async {
    DateTime? _newDate = await showDatePicker(
      context: context,
      initialDate: _dateTime2,
      firstDate: _dateTime1.add(const Duration(days: 1)),
      lastDate: DateTime.now(),
    );
    if(_newDate != null){
      setState(() {
        _dateTime2 = _newDate;
      });
    }
  }

  //Comme pour la première partie on prépare les variables qui récupéreront les données dans DateUtile
  void _calculateDuration(){
    setState(() {

      DateDuration dateDuration = DateUtil(_dateTime2).calculateDays(_dateTime1);

      _durationDays = dateDuration.days;
      _durationMonth = dateDuration.month;
      _durationYears = dateDuration.years;

    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
        backgroundColor:gradientEndColor,

        body: Container(
        decoration: BoxDecoration(
        gradient: LinearGradient(
        colors: [gradientStartColor, gradientEndColor],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
    ),
    ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Spacer(flex: 8,),
            const Center(
              child: Text(
                  "Choisis une première date ... : "
              ),
            ),
            const Spacer(),

          Container(
            color: Colors.white70,
            child:Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                InkWell(
                  onTap: _showDatePicker1,
                  child: Row(
                    children: [
                      const Icon(
                          Icons.date_range
                      ),
                      Text(
                        'Le ${_dateTime1.day}/${_dateTime1.month}/${_dateTime1.year} ? Je vois...',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
            const Spacer(),
            const Center(
              child: Text(
                  "Choisit une seconde date ... : "
              ),
            ),
            const Spacer(),

          Container(
            color: Colors.white70,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                InkWell(
                  onTap: _showDatePicker2,
                  child: Row(
                    children: [
                      const Icon(
                          Icons.date_range
                      ),
                      Text(
                        'Le ${_dateTime2.day}/${_dateTime2.month}/${_dateTime2.year} ? Très intéréssant ...',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
            const Spacer(flex: 2,),
            Center(
              child: ElevatedButton.icon(
                onPressed: _calculateDuration,
                icon: const Icon(
                    Icons.calculate
                ),
                label: const Text(
                    "Hmmm je le sens ... je vois ... je vois !!"
                ),
              ),
            ),
            const Spacer(flex: 2,),
            const Center(
              child: Text(
                  'Que la différence entre les 2 dates est de : '
              ),
            ),
            const Spacer(),
            Center(
              child: Text(
                  '$_durationYears an(s), $_durationMonth mois et $_durationDays jours !!'
              ),
            ),

            const Spacer(flex: 5,),

            Center(

              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  const Text(
                    '･ﾟ: *･ﾟ:* Tu es un/e bon/ne client/e, je vais te montrer l"étendu de mes pouvoirsssss *:･ﾟ*:･ﾟ',
                  ),
                  Image.asset("images/voyante.jpg",
                    height: 125.0,
                    width: 125.0,),
                ],
              ),
            ),

            Spacer(flex: 8,),
          ],
        ),
      ),
    );
  }
}