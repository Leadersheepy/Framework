package com.example.exercicedeuxframework

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
